# Rohan Bhave
# ITP 449
# HW2
# Question 2

# user inputs
int1 = int(input("Please enter an integer: "))
int2 = int(input("Please enter another integer: "))

# for loop from range 1 to int2
for x in range(1, int2 + 1):
    print(int1, "x", x, "=", int1*x)

